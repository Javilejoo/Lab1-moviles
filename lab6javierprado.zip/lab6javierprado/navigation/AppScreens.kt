package com.example.lab6javierprado.navigation

sealed class AppScreens(val route: String){
    object LoginScreen: AppScreens(route = "LoginScreen")
    object miGaleria: AppScreens(route = "miGaleria")
}
