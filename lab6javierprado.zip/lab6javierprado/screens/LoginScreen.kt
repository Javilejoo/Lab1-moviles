package com.example.lab6javierprado.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab6javierprado.InputType
import com.example.lab6javierprado.TextInput
import com.example.lab6javierprado.navigation.AppScreens
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.example.lab6javierprado.ui.theme.Lab6JavierPradoTheme


@Composable
fun LoginScreen(navController: NavController, modifier: Modifier = Modifier) {
    val passwordFocusRequester = FocusRequester()
    val focusManager = LocalFocusManager.current
    var areCredentialsValid by remember { mutableStateOf(false)}

    Surface(
        Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Sign in",
                modifier = modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .wrapContentSize(Alignment.TopCenter),
                fontWeight = FontWeight.Bold,
                fontSize = 25.sp,
                color = Color.Black
            )
            Text(
                "Sign in with your username and password",
                modifier = modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .wrapContentSize(Alignment.TopCenter),
                fontSize = 15.sp,
                color = Color.Black
            )
            Divider(
                color = Color.White.copy(alpha = 0.3f),
                thickness = 1.dp,
                modifier = Modifier.padding(top = 30.dp)
            )

            // TextInput para el nombre de usuario
            TextInput(
                InputType.Name,
                keyboardActions = KeyboardActions(onNext = {
                    passwordFocusRequester.requestFocus()
                })
            ) { username, password ->
                if (username == "javilejo" && password == "plataformas") {
                    // Las credenciales son válidas, navega a MiGaleria
                    areCredentialsValid = true
                    navController.navigate(route = AppScreens.miGaleria.route)
                } else {
                    // Las credenciales no son válidas, muestra un mensaje de error
                    areCredentialsValid = false
                }
            }

            // TextInput para la contraseña
            TextInput(
                InputType.Password,
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                }),
                focusRequester = passwordFocusRequester
            ) { username, password ->
                if (username == "javilejo" && password == "plataformas") {
                    // Las credenciales son válidas, navega a MiGaleria
                    areCredentialsValid = true
                    navController.navigate(route = AppScreens.miGaleria.route)
                } else {
                    // Las credenciales no son válidas, muestra un mensaje de error
                    areCredentialsValid = false
                }
            }

            Divider(
                color = Color.White.copy(alpha = 0.3f),
                thickness = 1.dp,
                modifier = Modifier.padding(top = 30.dp)
            )

            // Botón "SIGN UP" aquí, fuera de las TextInput
            Button(onClick = {
                navController.navigate(route = AppScreens.miGaleria.route)
            }, modifier = Modifier.fillMaxWidth()){
                Text(text = "SIGN IN", Modifier.padding(vertical = 8.dp))
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Don't have an account?",
                    color = Color.Black
                )
                Spacer(modifier = Modifier.weight(1f))
                TextButton(onClick = { /*TODO*/ }) {
                    Text(text = "SIGN UP" )
                }
            }


        }
    }
}

@Preview(showBackground = false )
@Composable
fun GreetingPreview() {
    Lab6JavierPradoTheme {
        LoginScreen(navController = rememberNavController())
    }
}