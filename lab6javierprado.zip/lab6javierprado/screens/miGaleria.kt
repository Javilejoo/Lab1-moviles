package com.example.lab6javierprado.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab6javierprado.R
import com.example.lab6javierprado.ui.theme.Lab6JavierPradoTheme

@Composable
fun MiGaleria(navController: NavController, modifier: Modifier = Modifier) {
    // Lista de obras de arte (debes incluir todas tus obras de arte aquí)
    val obrasDeArte = listOf(
        ObraDeArte(
            R.drawable.obra_1,
            "El Grito",
            "Edvard Munch",
            "1893"
        ),
        ObraDeArte(
            R.drawable.obra_2,
            "La Mona Lisa",
            "Leonardo da Vinci",
            "c. 1503-1506"
        ),
        ObraDeArte(
            R.drawable.obra_3,
            "La Noche Estrellada",
            "Vincent van Gogh",
            "1889"
        ),
        ObraDeArte(
            R.drawable.obra_4,
            "La Persistencia de la Memoria",
            "Salvador Dalí",
            "1931"
        ),
        ObraDeArte(
            R.drawable.obra_5,
            "Guernica",
            "Pablo Picasso",
            "1937"
        ),
        ObraDeArte(
            R.drawable.obra_6,
            "La Joven de la Perla",
            "saber",
            "1931"
        ),
        ObraDeArte(
            R.drawable.obra_7,
            "La creacion de adan",
            "saber",
            "1931"
        ),
        ObraDeArte(
            R.drawable.obra_8,
            " El Beso",
            "Salvador Dalí",
            "1931"
        ),
                ObraDeArte(
                R.drawable.obra_9,
        "La Lección de Anatomía del Dr. Nicolaes Tulp",
        "Salvador Dalí",
        "1931"
    ),
    ObraDeArte(
        R.drawable.obra__0,
        "Nighthawks",
        "Salvador Dalí",
        "1931"
    )
    )

    // Índice de la obra de arte actual
    var currentIndex by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val obraActual = obrasDeArte[currentIndex]

        // Imagen de la obra de arte
        Image(
            painter = painterResource(id = obraActual.imageRes),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp) // Ajusta la altura de la imagen según tus necesidades
                .clip(shape = MaterialTheme.shapes.medium),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Título de la obra
        Text(
            text = obraActual.title,
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Nombre del pintor
        Text(
            text = "Pintor: ${obraActual.painter}",
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Año de la obra
        Text(
            text = "Año: ${obraActual.year}",
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Botones "Previus" y "Next"
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    if (currentIndex > 0) {
                        currentIndex--
                    }
                },
                enabled = currentIndex > 0
            ) {
                Text(text = "Previus")
            }

            Button(
                onClick = {
                    if (currentIndex < obrasDeArte.size - 1) {
                        currentIndex++
                    }
                },
                enabled = currentIndex < obrasDeArte.size - 1
            ) {
                Text(text = "Next")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botón "Log Out"
        Button(
            onClick = {
                // Navegar de regreso a la pantalla de inicio de sesión
                navController.popBackStack()
            }
        ) {
            Text(text = "Log Out")
        }
    }
}


data class ObraDeArte(
    val imageRes: Int,
    val title: String,
    val painter: String,
    val year: String
)



@Preview(showBackground = false )
@Composable
fun previewGaleria() {
    Lab6JavierPradoTheme {
        MiGaleria(navController = rememberNavController())
    }
}